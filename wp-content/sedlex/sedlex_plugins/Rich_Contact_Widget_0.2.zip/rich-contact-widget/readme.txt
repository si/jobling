=== Rich Contact Widget ===
Contributors: tabrisrp
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=6V74BBTNMWW38&lc=FR&item_name=R%c3%a9my%20Perona&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted
Tags: microdata, microformat, widget, contact, rich snippets
Requires at least: 3.0
Tested up to: 3.4
Stable tag: 0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This contact widget comes with enhanced markup for microdatas & microformats, so that search engines can use it in their search results.

== Description ==

This contact widget comes with enhanced markup for microdatas & microformats, so that search engines can use it in their search results. They can help display contact informations about your business or yourself below your website in search results, and even a map with your location.

The telephone & email are linked so that visitors can click on it and make a call (through mobile or skype) or send a mail from their computer or their mobile devices.

More informations on microdatas microformats can be found here :
- http://schema.org
- http://microformats.org/

Feedbacks and suggestions for improvement are greatly appreciated !

== Installation ==

1. Upload the `rich-contact-widget` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the widgets section and add the Rich Contact Widget in the required sidebar
4. Fill the fields to add your contact informations
5. Save

== Frequently Asked Questions ==

== Screenshots ==

1. the widget configuration fields
2. The widget display on twenty ten theme

== Changelog ==

= 0.2 =
Added choice between Person or Company for microdata/microformat tagging
Added activity/job field

= 0.1 =
Initial release