<?php
/**
 * Deprecated FILE
 */

class WYSIJA_help_package {
	public function set_package(){
		return null;
	}
}