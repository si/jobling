<?php // concurrents widget config

define('FUNC', 'concurrents');
define('FORMAT', 'json');
