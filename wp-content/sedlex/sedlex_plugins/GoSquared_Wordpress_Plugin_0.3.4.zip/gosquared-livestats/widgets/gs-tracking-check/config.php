<?php // concurrents widget config

define('FUNC', 'list_sites');
define('FORMAT', 'json');
