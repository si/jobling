<div id="gs-admin-settings-page">
    <br />

    <a href="http://www.gosquared.com/" title="Go to the GoSquared homepage" target="_blank"><div id="gosquaredlogo"></div></a>

    <?php
        gs_fail($msg);
    ?>

</div>
