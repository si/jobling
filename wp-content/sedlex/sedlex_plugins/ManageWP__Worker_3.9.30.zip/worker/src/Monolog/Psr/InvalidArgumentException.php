<?php

class Monolog_Psr_InvalidArgumentException extends InvalidArgumentException
{
}
