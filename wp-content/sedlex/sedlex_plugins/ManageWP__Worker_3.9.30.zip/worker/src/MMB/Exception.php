<?php
/**
 * Created by miljenko.rebernisak@prelovac.com
 * Date: 3/7/14
  */

class MMB_Exception extends Exception{

} 
