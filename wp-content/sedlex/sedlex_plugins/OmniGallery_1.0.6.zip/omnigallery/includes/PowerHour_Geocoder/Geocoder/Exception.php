<?php

	class PowerHour_Geocoder_Exception extends Exception
	{
		
	}