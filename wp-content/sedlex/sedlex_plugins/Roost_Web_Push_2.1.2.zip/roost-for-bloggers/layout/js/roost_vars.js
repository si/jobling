    var _roost = _roost || [];
    _roost.push(['appkey', pushNotificationsByRoostMe.appkey]);	
