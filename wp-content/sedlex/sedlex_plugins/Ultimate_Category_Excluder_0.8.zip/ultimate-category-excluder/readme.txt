=== Ultimate Category Excluder ===
Contributors: planetmike
Donate link: http://www.planetmike.com/donations/
Tags: category, categories, exclude, visible, hidden, hide, invisible, remove
Requires at least: 3.1
Tested up to: 3.2
Stable tag: 0.8

Ultimate Category Excluder allows you to quickly and easily exclude categories from your front page, archives, and feeds.

== Description ==

Ultimate Category Excluder (UCE - unfortunately the same abbreviation as unsolicited commercial email) is a WordPress plugin that allows you to quickly and easily exclude categories from your front page, archives, and feeds. Just select which categories you want to be excluded, and UCE does all the work for you!

== Installation ==

1. Download Ultimate Category Excluder.
2. Unzip the ultimate-category-excluder.zip file.
3. Activate the plugin on your plugins page.
4. You can edit the options by going under "Options" and then "Category Exclusion."
5. (Optional) I suggest you subscribe to my <a href="http://www.planetmike.com/feed/">RSS feed</a> so you can stay informed about any updates to Ultimate Category Excluder.

== Changelog ==

= 0.8 =
* July 7, 2011 - Categories that do not have any posts in them will now appear on the list of categories.

= 0.7 =
* May 6, 2011 - Added internationalization (i18n) based on Patrick Skiebe's suggestion and code. He has provided a German translation. Feel free to send me other languages if you like.

= 0.6 =
* February 24, 2011 - Addressed a bug in UCE that didn’t handle multiple excluded categories correctly.

= 0.5 =
* February 24, 2011 - Addressed a bug in WP 3.1.

= 0.4 =
* October 10, 2009 - A user pointed out a bug when trying to filter down categories in the edit posts admin area. I believe I’ve fixed this, but let me know if you still have trouble.

= 0.3 =
* June 20, 2009 - James Revillini pointed out a few fairly obvious bugs. I’ve incorporated his changes into the software.

= 0.21 Beta =
* January 10, 2008 - Initial release, fixed file name bug, dashes vs. underscores

= 0.2 Beta =
* December 13, 2007 - Initial release, tweaked to refer to PlanetMike.com, no functionality changed

= 0.1 Beta =
* February 14, 2007 - Initial release
